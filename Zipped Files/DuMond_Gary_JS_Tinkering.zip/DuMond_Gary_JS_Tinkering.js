var childHeight = 49;

function displayIfChildIsAbleToRide(){
    if (childHeight > 52){
        console.log("Get on that ride, Kiddo!");
    } else {
        console.log("Sorry kiddo.  Maybe next year.");
    }
}

displayIfChildIsAbleToRide()