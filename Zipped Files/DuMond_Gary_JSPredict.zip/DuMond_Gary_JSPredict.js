
// When called, this will concatenate the integer to string
// and print 'I was born in 1986' to the console.
function myBirthYearFunc(){
    console.log('I was born in ' + 1986);
}

// This block of code does two things.  First, it overwrites
// the last function as they share the shame name.  Second,
// this has what is called a parameter, so when called it will
// take the parameter and concatenate it to the string, and 
// print it to the console.
function myBirthYearFunc(birthYearInput){
    console.log('I was born in ' + birthYearInput);
}

function add(num1,num2){
    console.log("Summing Numbers!");
    console.log("num1 is: " + num1);
    console.log("num2 is: " + num2);
    var sum = num1 + num2;
    console.log(sum);
}
// This function has multiple steps, so lets go over this one line 
// by line.

// For starters it will be looking for two parameters, both numbers.
// In the future we may want to include other function or methods to
// ensure and or convert these vars to numbers

// First line(18) will pirnt "summing Numbers!"
// Second Line will concatenate the num1 param and print it to the consloe 
// Third Line will concatenate the num2 param and print it to the consloe
// fourth line will create a third var called sum, add the params 
    // together, and store this new num in the var sum.
// Fifth line will print the value of sum to the console